package com.example.reviewbar;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.LayerDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btnsub;
    RatingBar ratingBar;
    //TextView textView;
    EditText editText;
    //CREATED BY: OD//

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    btnsub = findViewById(R.id.submit);

        ratingBar = (RatingBar) findViewById(R.id.ratingBar);
        editText = (EditText) findViewById(R.id.feedback);

        editText.getText().toString();
        LayerDrawable stars = (LayerDrawable) ratingBar.getProgressDrawable();
        stars.getDrawable(2).setColorFilter(Color.GREEN, PorterDuff.Mode.SRC_ATOP);

    }

    public void onSubmit(View view){
             float ratingValue = ratingBar.getRating();

        if(ratingValue < 2){
          //  textView.setText("Rating: "+ratingValue+"\nIs it that worse?");
            Toast.makeText(getApplicationContext(),"Rating: "+ratingValue+"" , Toast.LENGTH_SHORT).show();
            Toast.makeText(getApplicationContext(),editText.getText().toString(),Toast.LENGTH_SHORT).show();

            }

             else if(ratingValue <= 3 && ratingValue >= 2){
                 //textView.setText("Rating: "+ratingValue+"\nWe will try to be better !");
            Toast.makeText(getApplicationContext(),"Rating: "+ratingValue+"" , Toast.LENGTH_SHORT).show();
            Toast.makeText(getApplicationContext(),editText.getText().toString(),Toast.LENGTH_SHORT).show();

             }
               else if(ratingValue > 3 && ratingValue <= 4){
                 //  textView.setText("Rating: "+ratingValue+"\nThat means you are having a good time here :)");

            Toast.makeText(getApplicationContext(),"Rating: "+ratingValue+"" , Toast.LENGTH_SHORT).show();
            Toast.makeText(getApplicationContext(),editText.getText().toString(),Toast.LENGTH_SHORT).show();
               }
                else if(ratingValue > 4){
                      // textView.setText("Rating: "+ratingValue+"\nWow! We will keep up the good work ;)");
            Toast.makeText(getApplicationContext(),"Rating: "+ratingValue+"" , Toast.LENGTH_SHORT).show();
            Toast.makeText(getApplicationContext(),editText.getText().toString(),Toast.LENGTH_SHORT).show();

                }
            }
        	}
//CREATED BY: OD//


